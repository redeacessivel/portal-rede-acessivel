@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto sempython
py -3 -c "import certifi" >nul 2>nul
if errorlevel 1 (
  echo A preparar os certificados de seguranca. Aguarde.
  py -3 -m pip install --user --disable-pip-version-check certifi
  if errorlevel 1 goto semcertificado
)
py -3 servidor.py
exit /b 0
:semcertificado
echo.
echo Nao foi possivel instalar os certificados de seguranca.
echo Verifique a ligacao a Internet e execute novamente iniciar.bat.
pause
exit /b 1
:sempython
echo Esta versao precisa do Python 3 para atualizar os precos.
echo Instale o Python 3 e marque a opcao para o adicionar ao PATH.
pause
