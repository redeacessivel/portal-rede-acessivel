'use strict';
const euro=n=>new Intl.NumberFormat('pt-PT',{style:'currency',currency:'EUR'}).format(n);
const semAcentos=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const estado=document.querySelector('#estado-pesquisa'), resultadosEl=document.querySelector('#resultados'), carrinhoEl=document.querySelector('#carrinho'), totalEl=document.querySelector('#total');
let resultados=[], carrinho=JSON.parse(localStorage.getItem('cfCarrinho')||'[]');
const guardar=()=>localStorage.setItem('cfCarrinho',JSON.stringify(carrinho));

function descricaoProduto(p){
 const partes=[`Marca: ${p.marca||'não indicada'}`,`Embalagem: ${p.embalagem||'medida não indicada'}`,`Preço desta embalagem: ${euro(p.preco_embalagem??p.preco)}`];
 if(p.preco_unidade)partes.push(`Preço de comparação: ${p.preco_unidade}`);
 if(p.promocao)partes.push(p.preco_anterior?`Em promoção. Preço anterior: ${euro(p.preco_anterior)}`:'Em promoção');else partes.push('Sem promoção indicada');
 return partes.join('. ')+'.';
}
function desenharResultados(lista){ resultadosEl.replaceChildren(); if(!lista.length){estado.textContent='Nenhum produto encontrado.';return;}
 lista.sort((a,b)=>a.preco-b.preco).forEach(p=>{const li=document.createElement('li'); const h=document.createElement('h3');h.textContent=p.nome;
 const info=document.createElement('p');info.textContent=descricaoProduto(p);
 const detalhes=document.createElement('p');detalhes.id=`det-${p.id}`;detalhes.hidden=true;
 const ouvir=botao(`Ouvir detalhes de ${p.nome}`,()=>{detalhes.hidden=!detalhes.hidden;if(!detalhes.hidden){detalhes.textContent=`${p.nome}. ${descricaoProduto(p)} ${p.detalhes||'Não existem outros detalhes disponíveis.'}`;detalhes.tabIndex=-1;detalhes.focus();}ouvir.textContent=detalhes.hidden?`Ouvir detalhes de ${p.nome}`:`Ocultar detalhes de ${p.nome}`;});
 const menos=botao(`Diminuir quantidade de ${p.nome}`,()=>mudarQtdResultado(p,-1)); const qtd=document.createElement('span');qtd.id=`q-${p.id}`;qtd.className='quantidade';qtd.textContent=' Quantidade 1 '; const mais=botao(`Aumentar quantidade de ${p.nome}`,()=>mudarQtdResultado(p,1)); const add=botao(`Adicionar ${p.nome} ao carrinho`,()=>adicionar(p));
 p.qtdEscolhida=p.qtdEscolhida||1; qtd.textContent=` Quantidade ${p.qtdEscolhida} `; li.append(h,info,ouvir,detalhes,menos,qtd,mais,add); resultadosEl.append(li);});
 document.querySelector('#resultados-titulo').focus(); }
function botao(texto,acao){const b=document.createElement('button');b.type='button';b.textContent=texto;b.addEventListener('click',acao);return b;}
function mudarQtdResultado(p,d){p.qtdEscolhida=Math.max(1,(p.qtdEscolhida||1)+d);document.querySelector(`#q-${CSS.escape(p.id)}`).textContent=` Quantidade ${p.qtdEscolhida} `;estado.textContent=`Quantidade de ${p.nome}: ${p.qtdEscolhida}.`;}
function adicionar(p){const existente=carrinho.find(x=>x.id===p.id);if(existente)existente.quantidade+=p.qtdEscolhida||1;else carrinho.push({...p,quantidade:p.qtdEscolhida||1});guardar();desenharCarrinho();estado.textContent=`${p.nome} adicionado. Total atual ${euro(total())}.`;}
const total=()=>carrinho.reduce((s,p)=>s+p.preco*p.quantidade,0);
function desenharCarrinho(){carrinhoEl.replaceChildren();document.querySelector('#resumo-carrinho').textContent=carrinho.length?`${carrinho.length} tipos de produto no carrinho.`:'O carrinho está vazio.';
 carrinho.forEach((p,i)=>{const li=document.createElement('li');const texto=document.createElement('p');texto.textContent=`${p.nome}. Embalagem: ${p.embalagem||'medida não indicada'}. Preço de cada embalagem: ${euro(p.preco_embalagem??p.preco)}. Quantidade de embalagens: ${p.quantidade}. Subtotal: ${euro(p.preco*p.quantidade)}.`;
 li.append(texto,botao(`Diminuir ${p.nome}`,()=>alterarCarrinho(i,-1)),botao(`Aumentar ${p.nome}`,()=>alterarCarrinho(i,1)),botao(`Remover ${p.nome}`,()=>remover(i)));carrinhoEl.append(li);});totalEl.textContent=`Total atual: ${euro(total())}.`;}
function alterarCarrinho(i,d){carrinho[i].quantidade=Math.max(1,carrinho[i].quantidade+d);guardar();desenharCarrinho();totalEl.textContent=`Total atualizado: ${euro(total())}.`;}
function remover(i){const nome=carrinho[i].nome;carrinho.splice(i,1);guardar();desenharCarrinho();totalEl.textContent=`${nome} removido. Total atualizado: ${euro(total())}.`;}
async function pesquisar(){const q=document.querySelector('#pesquisa').value.trim();if(!q){estado.textContent='Escreva o produto que procura.';return;} estado.textContent=`A pesquisar ${q}. Aguarde.`;resultadosEl.replaceChildren();
 try{const r=await fetch(`/api/pesquisar?q=${encodeURIComponent(q)}`);const dados=await r.json();if(!r.ok)throw new Error(dados.erro||'Falha na pesquisa');resultados=dados.produtos;document.querySelector('#origem-precos').textContent=dados.aviso;desenharResultados(resultados);estado.textContent=`Foram encontrados ${resultados.length} produtos. Ordenados do mais barato para o mais caro.`;}catch(e){estado.textContent=`Não foi possível atualizar os preços: ${e.message}`;}}
document.querySelector('#pesquisar').addEventListener('click',pesquisar);document.querySelector('#pesquisa').addEventListener('keydown',e=>{if(e.key==='Enter')pesquisar();});
document.querySelector('#promocoes').addEventListener('click',()=>{const p=resultados.filter(x=>x.promocao);desenharResultados(p);estado.textContent=p.length?`${p.length} produtos em promoção.`:'Não foram encontradas promoções nesta pesquisa.';});
document.querySelector('#consultar-total').addEventListener('click',()=>{totalEl.textContent=`A despesa está em ${euro(total())}, com ${carrinho.reduce((s,p)=>s+p.quantidade,0)} unidades.`;totalEl.focus();});
document.querySelector('#limpar-carrinho').addEventListener('click',()=>{if(carrinho.length&&confirm('Tem a certeza de que pretende esvaziar o carrinho?')){carrinho=[];guardar();desenharCarrinho();}});
document.querySelector('#guardar-zona').addEventListener('click',()=>{const v=document.querySelector('#codigo-postal').value.trim();const e=document.querySelector('#estado-zona');if(!/^\d{4}-\d{3}$/.test(v)){e.textContent='Código postal inválido.';return;}localStorage.setItem('cfCP',v);e.textContent='Código postal guardado apenas neste computador.';});
document.querySelector('#codigo-postal').value=localStorage.getItem('cfCP')||'2625-102';desenharCarrinho();
