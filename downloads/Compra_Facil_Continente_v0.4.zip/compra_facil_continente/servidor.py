import html, json, re, ssl, threading, time, unicodedata, urllib.parse, urllib.request, webbrowser
import certifi
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

PORTA=8765
AGENTE='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/142 Safari/537.36'

def texto(s): return re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]+>',' ',s))).strip()
def numero(s):
    try:return float(s.replace('.','').replace(',','.').replace('€','').strip())
    except:return None

def detalhes_embalagem(valor):
    """Extrai a quantidade comercial sem confundir preço da embalagem com preço unitário."""
    t=texto(str(valor))
    padroes=[
        r'\b(?:emb\.?\s*)?(\d+\s*[xX]\s*\d+(?:[,.]\d+)?\s*(?:ml|cl|l|lt|g|gr|kg|unidades?|un\.?|doses?|rolos?|saquetas?|cápsulas?))\b',
        r'\b(?:emb\.?\s*)?(\d+(?:[,.]\d+)?\s*(?:ml|cl|l|lt|g|gr|kg|unidades?|un\.?|doses?|rolos?|saquetas?|cápsulas?))\b'
    ]
    for padrao in padroes:
        m=re.search(padrao,t,re.I)
        if m:return m.group(1).replace('lt','litro',1) if m.group(1).lower().endswith('lt') else m.group(1)
    return ''

def preco_referencia(valor):
    t=texto(str(valor))
    m=re.search(r'(\d+[,.]\d{1,2})\s*€\s*/\s*(kg|l|lt|un\.?|dose|100\s*g|100\s*ml)',t,re.I)
    if not m:return ''
    unidade={'lt':'litro','l':'litro','kg':'quilo','un':'unidade','un.':'unidade','dose':'dose'}.get(m.group(2).lower(),m.group(2))
    return f"{m.group(1)} euros por {unidade}"

def preco_anterior(valor):
    t=texto(str(valor))
    m=re.search(r'(?:PVPR|preço\s+anterior)\s*(\d+[,.]\d{1,2})\s*€',t,re.I)
    return numero(m.group(1)) if m else None

def preco_atual_cartao(valor):
    t=texto(str(valor))
    anterior=preco_anterior(t)
    candidatos=[]
    for m in re.finditer(r'(\d+[,.]\d{1,2})\s*€(?!\s*/)',t,re.I):
        n=numero(m.group(1))
        if n is not None:candidatos.append(n)
    if not candidatos:return None
    if anterior is not None:
        diferentes=[n for n in candidatos if n != anterior]
        if diferentes:return diferentes[0]
    return candidatos[0]

def extrair_productos(conteudo):
    produtos=[]; vistos=set()
    # Primeiro tenta dados estruturados de produto.
    for bloco in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',conteudo,re.I|re.S):
        try:
            dados=json.loads(html.unescape(bloco))
            pilha=dados if isinstance(dados,list) else [dados]
            while pilha:
                x=pilha.pop()
                if isinstance(x,dict):
                    if x.get('@type')=='Product':
                        oferta=x.get('offers') or {}; oferta=oferta[0] if isinstance(oferta,list) and oferta else oferta
                        p=numero(str(oferta.get('price','')))
                        if p is not None:
                            nome=str(x.get('name','Produto')); ident=str(x.get('sku') or x.get('productID') or abs(hash(nome)))
                            base=' '.join(str(x.get(k,'')) for k in ('name','description','size','weight'))
                            anterior=numero(str(oferta.get('highPrice',''))) if oferta.get('highPrice') else None
                            produtos.append({'id':ident,'nome':nome,'marca':(x.get('brand') or {}).get('name','') if isinstance(x.get('brand'),dict) else str(x.get('brand','')),'embalagem':detalhes_embalagem(base),'preco':p,'preco_embalagem':p,'preco_unidade':preco_referencia(base),'preco_anterior':anterior,'promocao':bool(anterior and anterior>p),'url':str(x.get('url','')),'detalhes':texto(str(x.get('description','')))[:500]});vistos.add(ident)
                    pilha.extend(v for v in x.values() if isinstance(v,(dict,list)))
                elif isinstance(x,list): pilha.extend(x)
        except: pass
    # Complemento para cartões HTML do Continente/Salesforce Commerce Cloud.
    cartoes=re.findall(r'<(?:div|article)[^>]+(?:product-tile|productTile)[^>]*>(.*?)(?=<(?:div|article)[^>]+(?:product-tile|productTile)|$)',conteudo,re.I|re.S)
    for c in cartoes:
        nome_m=re.search(r'(?:product-name|pdp-link)[^>]*>(.*?)</',c,re.I|re.S); p=preco_atual_cartao(c)
        if not(nome_m and p is not None):continue
        nome=texto(nome_m.group(1)); ident=str(abs(hash(nome)));conteudo_cartao=texto(c);anterior=preco_anterior(c)
        marca_m=re.search(r'(?:product-brand|brand)[^>]*>(.*?)</',c,re.I|re.S)
        if ident not in vistos: produtos.append({'id':ident,'nome':nome,'marca':texto(marca_m.group(1)) if marca_m else '','embalagem':detalhes_embalagem(conteudo_cartao),'preco':p,'preco_embalagem':p,'preco_unidade':preco_referencia(conteudo_cartao),'preco_anterior':anterior,'promocao':bool(anterior and anterior>p) or bool(re.search(r'promo|desconto|PVPR',c,re.I)),'url':'','detalhes':''});vistos.add(ident)
    return produtos

def pesquisa(q):
    url='https://www.continente.pt/pesquisa/?q='+urllib.parse.quote(q)
    req=urllib.request.Request(url,headers={'User-Agent':AGENTE,'Accept-Language':'pt-PT,pt;q=0.9'})
    contexto=ssl.create_default_context(cafile=certifi.where())
    with urllib.request.urlopen(req,timeout=25,context=contexto) as r: conteudo=r.read().decode('utf-8','replace')
    produtos=extrair_productos(conteudo)
    if not produtos: raise RuntimeError('o Continente não forneceu resultados legíveis à aplicação')
    return produtos

class Servidor(SimpleHTTPRequestHandler):
    def do_GET(self):
        u=urllib.parse.urlparse(self.path)
        if u.path=='/api/pesquisar':
            q=urllib.parse.parse_qs(u.query).get('q',[''])[0].strip()
            try:
                produtos=pesquisa(q)
                corpo={'produtos':produtos,'aviso':'Preços obtidos agora do Continente. Confirme-os antes do pagamento.'};codigo=200
            except Exception as e: corpo={'erro':str(e)};codigo=502
            dados=json.dumps(corpo,ensure_ascii=False).encode();self.send_response(codigo);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(dados)));self.end_headers();self.wfile.write(dados);return
        return super().do_GET()
    def log_message(self,formato,*args): pass

if __name__=='__main__':
    endereco=f'http://127.0.0.1:{PORTA}/index.html'
    threading.Timer(1,lambda:webbrowser.open(endereco)).start()
    print('Compra Facil em funcionamento. Para fechar, prima Control+C.')
    ThreadingHTTPServer(('127.0.0.1',PORTA),Servidor).serve_forever()
